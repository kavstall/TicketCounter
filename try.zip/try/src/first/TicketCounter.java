package first;

public class TicketCounter {
	
	public void runing(){
		
	}
	
	public boolean isEmpty(int count){
		
		boolean result = false;
		
		return result;
	}

}
